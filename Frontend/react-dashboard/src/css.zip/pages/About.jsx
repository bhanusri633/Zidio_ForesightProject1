import Layout from "../components/Layout";

function About() {

  return (

    <Layout>

      <h2 style={{ color: "white", marginBottom: "20px" }}>
        ℹ About Project
      </h2>

      <div className="chart-card">

        <h3>AI Powered Sales Forecasting Dashboard</h3>

        <p>
          This dashboard predicts future retail sales using Machine Learning.
        </p>

        <br/>

        <h3>Technologies Used</h3>

        <ul>
          <li>React JS</li>
          <li>Flask API</li>
          <li>Python</li>
          <li>Scikit-Learn</li>
          <li>Pandas</li>
          <li>Recharts</li>
        </ul>

        <br/>

      </div>

    </Layout>

  );
}

export default About;