import { useState } from "react";
import axios from "axios";
import "../styles/prediction.css";
import { FaRobot } from "react-icons/fa";

function PredictionCard() {

  const [quantity, setQuantity] = useState("");
  const [price, setPrice] = useState("");
  const [year, setYear] = useState("");
  const [month, setMonth] = useState("");
  const [day, setDay] = useState("");

  const [prediction, setPrediction] = useState(null);

  const predictSales = async () => {

    try {

      const response = await axios.post(
        "http://127.0.0.1:5000/predict",
        {
          Quantity: Number(quantity),
          Price: Number(price),
          Year: Number(year),
          Month: Number(month),
          Day: Number(day),
        }
      );

      setPrediction(response.data["Predicted Sales"]);

    } catch (error) {

      console.log(error);

      alert("Prediction Failed");

    }

  };

  return (

    <div className="prediction-card">

      <h3>
        <FaRobot /> Sales Prediction
      </h3>

      <input
        type="number"
        placeholder="Quantity"
        value={quantity}
        onChange={(e)=>setQuantity(e.target.value)}
      />

      <input
        type="number"
        placeholder="Price"
        value={price}
        onChange={(e)=>setPrice(e.target.value)}
      />

      <input
        type="number"
        placeholder="Year"
        value={year}
        onChange={(e)=>setYear(e.target.value)}
      />

      <input
        type="number"
        placeholder="Month"
        value={month}
        onChange={(e)=>setMonth(e.target.value)}
      />

      <input
        type="number"
        placeholder="Day"
        value={day}
        onChange={(e)=>setDay(e.target.value)}
      />

      <button onClick={predictSales}>
        Predict Sales
      </button>

      <div className="prediction-result">

        <span>Predicted Revenue</span>

        <h2>

          {prediction !== null
            ? `₹${prediction.toFixed(2)}`
            : "₹0.00"}

        </h2>

        <p>

          {prediction !== null
            ? "Prediction Complete"
            : "Enter values and click Predict"}

        </p>

      </div>

    </div>

  );

}

export default PredictionCard;