import { useEffect, useState } from "react";
import Layout from "../components/Layout";
import Charts from "../components/Charts";
import { getDashboardData } from "../api/api";

function Analytics() {

  const [dashboardData, setDashboardData] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const response = await getDashboardData();
      setDashboardData(response.data);
    } catch (err) {
      console.log(err);
    }
  };

  if (!dashboardData) {
    return (
      <Layout>
        <h2 style={{ color: "white" }}>Loading...</h2>
      </Layout>
    );
  }

  return (
    <Layout>

      <h2 style={{ color: "white", marginBottom: "20px" }}>
        📊 Analytics Dashboard
      </h2>

      <Charts
        monthly={dashboardData.monthly}
        country={dashboardData.country}
        products={dashboardData.products}
      />

    </Layout>
  );
}

export default Analytics;